using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _1322_Lab_14 {
	
    class HelperClass {

        private List<string> words;

        public HelperClass(List<string> words) {
            this.words = words;
        }

        //function which replaces <>
        public void ReplaceHTML() {

            /* Write your logic to replace the tags and print the text here */

        }

    }
}
